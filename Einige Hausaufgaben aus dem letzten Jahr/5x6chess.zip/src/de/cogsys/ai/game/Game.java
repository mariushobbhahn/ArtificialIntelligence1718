package de.cogsys.ai.game;

import java.util.List;

/**
 * @param <M> Der generische Parameter M legt den Datentyp fuer
 * einen Zug fest.
 * @author Sebastian Otte
 */
public interface Game<M> {
    
    public static final int DRAW = -1;
    
    /**
     * Gibt die Nummer des Spielers zurueck, der gerade an der Reihe ist. 
     */
    public int getCurrentPlayer();
    /**
     * Gibt die Nummer des anderen Spielers zurueck.
     */
    public int getOtherPlayer();
    /**
     * Gibt zurueck, ob der uebergebene Spieler das Spiel bereits gewonnen hat. 
     */
    public boolean wins(final int player);
    /**
     * Ueberprueft, ob das Spiel beendet ist, d.h. ob es keine gueltigen Zuege mehr
     * gibt oder das Spiel gewonnen wurde.
     */
    public boolean ends();
    /**
     * Generiert eine List aller in der aktuellen Spielkonfiguration gueltigen Zuege.
     */
    public List<M> generateValidMoves();
    /**
     * Fuehrt fuer den aktuellen Spieler einen Zug durch. Diese Methode sorgt ausserdem
     * fuer einen Spielerwechsel und liefert schliesslich die neue Spielkonfiguration
     * nach dem Zug als KOPIE zurueck.
     */
    public Game<M> performMove(final M move);
}