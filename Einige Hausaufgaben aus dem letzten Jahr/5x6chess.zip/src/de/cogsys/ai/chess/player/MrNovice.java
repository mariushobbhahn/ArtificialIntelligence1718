package de.cogsys.ai.chess.player;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import de.cogsys.ai.chess.control.ChessGameConsole;
import de.cogsys.ai.chess.game.ChessGame;
import de.cogsys.ai.chess.game.ChessMove;
import de.cogsys.ai.chess.game.Figure;

/**
 * @author Sebastian Otte
 */
public class MrNovice implements ChessPlayer {
	
    private static final long TIME_THRESHOLD = 2000;
    private static final int  DEFAULT_DEPTH  = 4;
	
	private int mycolor;
		
    private Random rnd;
    private long   delay;
    private int    depth;

    public MrNovice(final Random rnd, final long delay, final int depth) {
        this.rnd   = rnd;
        this.delay = delay;
        this.depth = depth;
    }
        
    
    public MrNovice(final Random rnd) {
        this(rnd, 0, DEFAULT_DEPTH);
    }
    

    public MrNovice(final long delay) {
        this(new Random(System.currentTimeMillis()), delay, DEFAULT_DEPTH);

    }

    public MrNovice(final long delay, final int depth) {
        this(new Random(System.currentTimeMillis()), delay, depth);

    }
    public MrNovice() {
        this(0);
    }


    @Override
    public void initialize(final int color) {
        //
        this.mycolor = color;
    }
    
    private static final double SCORE_WIN    = 1000;
    private static final double SCORE_LOST   = -1000;
    private static final double SCORE_DRAW   = 0;
    //
    private static final double SCORE_PAWN   = 10;
    private static final double SCORE_ROOK   = 50;
    private static final double SCORE_BISHOP = 50;
    private static final double SCORE_KNIGHT = 50;
    private static final double SCORE_QUEEN  = 200;
    //
    private static final double SCORE_CHECK     = 100;
    private static final double SCORE_OWNCHECK  = -100;
    
    private static double evaluateGame(final ChessGame game, final int color) {
        //
        double score = 0;
        //
        if (game.wins(color)) {
            return SCORE_WIN;
        } else if (game.wins(Figure.other_color(color))) {
            return SCORE_LOST;
        } else if (game.isDraw()) {
            return SCORE_DRAW;
        } 
        //
        if (game.isCheck(color)) {
            score += SCORE_OWNCHECK;
        }
        if (game.isCheck(Figure.other_color(color))) {
            score += SCORE_CHECK;
        }
        //
        final int[] board = game.getBoard();
        for (int i = 0; i < board.length; i++) {
            final int cell_value  = board[i];
            final int cell_figure = Figure.figure(cell_value);
            final int cell_color  = Figure.color(cell_value);
            //
            double figurescore = 0;
            //
            switch (cell_figure) {
                case Figure.PAWN:
                    figurescore = SCORE_PAWN; 
                    break;
                case Figure.ROOK:
                    figurescore = SCORE_ROOK;
                    break;
                case Figure.BISHOP:
                    figurescore = SCORE_BISHOP;
                    break;
                case Figure.KNIGHT:
                    figurescore = SCORE_KNIGHT;
                    break;
                case Figure.QUEEN:
                    figurescore = SCORE_QUEEN;
                    break;
            }
            //
            if (cell_color == color) {
                score += figurescore;
            } else {
                score -= figurescore;
            }
        }
        //
        return score;
    }
    
    private double min(final ChessGame game, final ChessGameConsole c, final int depth) {
        if (
            (depth <= 0) || 
            game.ends() ||
            (c.getTimeLeft() < TIME_THRESHOLD)            
        ) {
            return evaluateGame(game, this.mycolor);
        }
        //
        final List<ChessMove> moves = game.generateValidMoves();
        Collections.shuffle(moves, this.rnd);
        double minscore = Double.POSITIVE_INFINITY;
        //
        for (int i = 0; i < moves.size(); i++) {
            //
            final ChessMove move      = moves.get(i);
            final ChessGame aftermove = game.performMove(move);
            final double    score     = max(aftermove, c, depth - 1);
            //
            if (score < minscore) {
                minscore = score;
            }
        }
        //
        return minscore;        
    }
    
    private double max(final ChessGame game, final ChessGameConsole c, final int depth) {
        if (
            (depth <= 0) || 
            game.ends() ||
            (c.getTimeLeft() < TIME_THRESHOLD)            
        ) {
            return evaluateGame(game, this.mycolor);
        }
        //
        final List<ChessMove> moves = game.generateValidMoves();
        Collections.shuffle(moves, this.rnd);
        double maxscore = Double.NEGATIVE_INFINITY;
        //
        for (int i = 0; i < moves.size(); i++) {
            //
            final ChessMove move      = moves.get(i);
            final ChessGame aftermove = game.performMove(move);
            final double    score     = min(aftermove, c, depth - 1);
            //
            if (score > maxscore) {
                maxscore = score;
            }
        }
        //
        return maxscore;
    }
    
    @Override
    public void generateNextMove(final ChessGameConsole c) {
        //
        final long timeleft = c.getTimeLeft();
        //
        final ChessGame game = c.getGame();
        final List<ChessMove> moves = game.generateValidMoves();
        //
        final List<ChessMove> bestmoves = new ArrayList<ChessMove>();
        //
        double maxscore = Double.NEGATIVE_INFINITY;
        //
        for (int i = 0; i < moves.size(); i++) {
            //
            final ChessMove move      = moves.get(i);
            final ChessGame aftermove = game.performMove(move);
            final double    score     = min(aftermove, c, this.depth);
            //
            if (score > maxscore) {
                bestmoves.clear();
                bestmoves.add(move);
                maxscore = score;
            } else if (score == maxscore) {
                bestmoves.add(move);
            }
        }
        //
        final ChessMove bestmove = bestmoves.get(rnd.nextInt(bestmoves.size()));
        c.updateMove(bestmove);
        //
        final long delaydiff = delay - (timeleft - c.getTimeLeft());
        if (delaydiff > 0) {
            try {
                Thread.sleep(this.delay);
            } catch (InterruptedException e) {
                //
            }            
        }
    }        

}