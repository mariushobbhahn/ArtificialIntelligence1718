package de.cogsys.ai.chess.gui;


/**
 * @author Sebastian Otte
 */
public interface ChessGamePanelListener {
    public void clickedCell(final int i, final int j);
}