package de.cogsys.ai.chess.gui;

import javax.swing.BoxLayout;
import javax.swing.JFrame;

/**
 * @author Sebastian Otte
 */
public class MainFrame extends JFrame {
	private static final long serialVersionUID = 1L;
	
	private ChessGamePanel gamepanel;
	private StatusPanel    statuspanel;
	
	public ChessGamePanel getGamePanel() {
	    return this.gamepanel;
	}
	
	public StatusPanel getStatusPanel() {
	    return this.statuspanel;
	}
	
	public MainFrame() {
		super("5x6 Chess - Cogsys AI Competition 2016/2017");
		//
		this.setLayout(new BoxLayout(this.getContentPane(), BoxLayout.Y_AXIS));
		//
		this.gamepanel = new ChessGamePanel();
		this.statuspanel = new StatusPanel();
		//
		this.add(this.gamepanel);
		this.add(this.statuspanel);
		this.pack();
		//
		this.setResizable(false);
	}
	
	
}