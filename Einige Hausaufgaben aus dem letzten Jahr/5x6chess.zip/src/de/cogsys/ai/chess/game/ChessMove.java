package de.cogsys.ai.chess.game;


/**
 * @author Sebastian Otte
 */
public class ChessMove {
    /**
     * Row of the source position.
     */
    public final int i1;
    /**
     * Column of the source position.
     */
    public final int j1;
    /**
     * Row of the target position.
     */
    public final int i2;
    /**
     * Column of the target position.
     */
    public final int j2;
    
    public ChessMove(final int i1, final int j1, final int i2, final int j2) {
    	this.i1 = i1;
    	this.j1 = j1;
    	this.i2 = i2;
    	this.j2 = j2;
    }
    
    
}

