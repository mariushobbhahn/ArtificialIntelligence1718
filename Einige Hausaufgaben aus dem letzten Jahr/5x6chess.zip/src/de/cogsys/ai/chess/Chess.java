package de.cogsys.ai.chess;

import java.awt.image.BufferedImage;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.UIManager;

import de.cogsys.ai.chess.control.ChessGameControl;
import de.cogsys.ai.chess.game.ChessGame;
import de.cogsys.ai.chess.gui.ChessRes;
import de.cogsys.ai.chess.gui.MainFrame;
import de.cogsys.ai.chess.player.ChessPlayer;
import de.cogsys.ai.chess.player.Human;
import de.cogsys.ai.chess.player.MrNovice;
import de.cogsys.ai.chess.player.MrRandom;
//import de.cogsys.ai.chess.player.YourAgent;


/**
 * @author Sebastian Otte
 */
public class Chess {
	
    public static <T> T selectDiaglog(
        final String caption,
        final String message,
        final T[] options,
        final T defaultoption,
        final Icon icon
    ) {
        //
        @SuppressWarnings("unchecked")
        final T result = (T)JOptionPane.showInputDialog(
            null, message, caption, JOptionPane.QUESTION_MESSAGE, icon, options, defaultoption
        );
        //
        return result;
    }

    
    public static final String[] agents = {
        "Human",
        "MrNovice (depth 2)",
        "MrNovice (depth 3)",
        "MrNovice (depth 4)",
        "MrRandom"
        //,"your agent name"
    };
    
    public static ChessPlayer createAgent(final String agent) {
        if (agent.equals(agents[0]))   return new Human();
        if (agent.equals(agents[1]))   return new MrNovice(1000, 2);
        if (agent.equals(agents[2]))   return new MrNovice(1000, 3);
        if (agent.equals(agents[3]))   return new MrNovice(1000, 4);
        if (agent.equals(agents[4]))   return new MrRandom(1000);
        //if (agent.equals(agents[5]))   returen new YourAgent();
        return null;
    }    
    
    
    public static void main(String[] args) {
	    //
	    try {
            UIManager.setLookAndFeel(
                UIManager.getSystemLookAndFeelClassName()
            );
        } catch (Exception e) {};
        //
        String player1name = agents[0];
        String player2name = agents[1];
        //
	    final MainFrame frame = new MainFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//
        do {
            //
            // select player 1
            //
            player1name = selectDiaglog(
                "Select Player 1",
                "Select one of the following agents:", 
                agents,
                player1name,
                new ImageIcon(ChessRes.IMG_WHITE_KING.getScaledInstance(128, 128, BufferedImage.SCALE_SMOOTH))
            ); 
            if (player1name == null) {
                break;
            }
            //
            // select player 2
            //
            player2name = selectDiaglog(
                "Select Player 2",
                "Select one of the following agents:", 
                agents,
                player2name,
                new ImageIcon(ChessRes.IMG_BLACK_KING.getScaledInstance(128, 128, BufferedImage.SCALE_SMOOTH))
            ); 
            if (player2name == null) {
                break;
            }
            //
        	final ChessGameControl control = new ChessGameControl(
        	    frame, frame.getGamePanel(), frame.getStatusPanel(),
        	    true
        	);
    		//
    		control.start(
    		    new ChessGame(), 
    		    createAgent(player1name),
                createAgent(player2name)
            );
    		//
        } while (
            JOptionPane.showConfirmDialog(
                null, 
                "Start a new game?",
                frame.getTitle(),
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null
            ) == JOptionPane.YES_OPTION
        );
        //
        System.exit(0);
	}
	
}
