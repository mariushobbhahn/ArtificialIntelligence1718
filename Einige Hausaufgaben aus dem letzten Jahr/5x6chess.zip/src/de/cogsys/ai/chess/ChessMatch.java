package de.cogsys.ai.chess;

import javax.swing.JFrame;

import de.cogsys.ai.chess.control.ChessGameControl;
import de.cogsys.ai.chess.game.ChessGame;
import de.cogsys.ai.chess.gui.MainFrame;
import de.cogsys.ai.chess.player.ChessPlayer;
import de.cogsys.ai.chess.player.Human;
import de.cogsys.ai.chess.player.MrNovice;

public class ChessMatch {
	
	
	
	public static void main(String[] args) throws InstantiationException, IllegalAccessException, ClassNotFoundException {
		/*
		args = new String[]{
			"de.cogsys.ai.chess.player.MrRandom",
			"de.cogsys.ai.chess.player.MrRandom",
			"false"
		};
		*/
		
		final boolean showgui = (args.length == 3)?(Boolean.parseBoolean(args[2])):(false); 
		
		ClassLoader loader = Chess.class.getClassLoader();
		
		final String player1_class = args[0];
		final String player2_class = args[1];
		
		final ChessPlayer player1 = (ChessPlayer)loader.loadClass(player1_class).newInstance();
		final ChessPlayer player2 = (ChessPlayer)loader.loadClass(player2_class).newInstance();
		
		final String player1_name = player1.getClass().getSimpleName();
		final String player2_name = player2.getClass().getSimpleName();
		
		final MainFrame frame = new MainFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//
		final ChessGameControl control = new ChessGameControl(
		    frame, frame.getGamePanel(), frame.getStatusPanel(),
		    showgui
		);
		//
		int result = -2; // ERROR
		//
		try {
			result = control.start(new ChessGame(), player1, player2);
		} catch (Exception e) {
			//
			// In case of exception result is -2
			//
		}
		
			
		System.out.println();
		System.out.println(player1_name + " " + player2_name + " " + result);
		
		if (!showgui) {
			System.exit(0);
		}
		
	}
	
	
	
	
}