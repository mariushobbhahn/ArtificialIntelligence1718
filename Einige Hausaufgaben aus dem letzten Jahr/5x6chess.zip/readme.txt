Notes for Assignment 9 (MinitChess AI)
--------------------------------------------------------------------------------

o We recommend using the eclipse IDE for working on this assignment. Create a
  new Java project and import the "src" folder. Make sure that the "resources"
  folder is a subfolder of "src", since it contains the graphics for the game's
  gui.

o The game gui can be started with the main method of the Chess class. To be
  able to use your agent in gui, you will need to add it to the list of agents
  in this class.

o For testing your agent, please use the command line option "-Xmx2g" which
  limits the size of the JVM heap to 2GB (in eclipse you can add this under
  "Run -> Run Configurations -> Chess -> Arguments -> VM arguments"). If your
  agents crosses this threshold, an OutOfMemoryError will be thrown which can be
  caught if you want.

o For experimenting ,you can change the time per move by adjusting the cconstant 
  PLAYER_TIMEOUT in the class GameControll (time in ms). Please note that for
  the evaluation, the value 30000 will be used.

o If your agent is still running after the timelimit has passed, your agent will
  lose unless you have registered a preliminary move with updateMove (see next
  point). The thread running your agent will also receive an interrupt signal.
  This does not automatically kill the thread, but it will set a flag which can
  be checked with

    Thread.currentThread().isInterrupted()

  After receiving the interrupt, your agent must stop running at the next
  convenient time to free up resources.

o Your submission should consist of (the source code for) a class implementing
  the ChessPlayer interface, you are not allowed to modify any other file in the
  program, so please make sure your agent works with the base version of the
  game as distributed.

  Important: please include some documentation for your agent (either as
  comments in the java file or as a separate document). Document which algorithm
  you are using, what the idea behind your heuristic is (if applicable), etc.
  Also document some games against the included agents (see below).

o The most important part of the agent ist the method generateNextMove. The
  argument to this method is an instance of the ChessGameConsole interface. This
  interface gives access to the following methods:

  - getGame: returns the current game state

  - getTimeLeft: returns the milliseconds left for the current turn

  - updateMove: registers the move you want to play. This can be called multiple
    times to update the selected move and it is advisable to call this method at
    least once early in the turn to avoid forfeiting the game if the computation
    takes longer than expected.

o If possible, please avoid splitting your implementation across multiple files.
  If you need to create additional classes, please create them as inner classes
  (even if this might not be software engineering best practice).

o Your code cannot rely on any libraries other than the java class libraries for
  Java 1.8

o Your agent should be single-threaded. While a multi-threaded agent will get
  marks for the assignment, it will be disqualified from the tournament.

o The class ChessGame contains several methods that provide information on the
  current state of the game, which can of course be used by your agent.

o The chessboard is represented as a simple int array which can be manipulated
  with the get and set methods of the ChessGame class. The Figure class is used
  to encode the information about the pieces on the squares of the chessboard. A
  square can either contain the value Figure.EMPTY or an encoding of the piece
  and color, which can be accessed with Figure.figure(..) and Figure.color(..).

o A move consists of the 4-tuple (i1, j1, i2, j2), where

  - i1, j1 is the square of the piece that should be moved

  - i2, j2 is the square the piece should move to

  The method generateValidMoves() can be used to generate all legal moves in the
  current game state. There is also a version of this method that allows you to
  specify the player for whom to generate moves.

o The human player is controlled with the mouse:

  - click a piece to select it

  - if it gets a red background, this piece has no legal moves

  - if the piece has legal moves, it will get a green background and all the
    squares it can move to get a blue background

  - by clicking on one of the blue squares that move is selected

o Two agents are included in this framework to allow you to test your agent:

  - MrRandom: A very primitive agent that selects its moves randomly from the
    list of legal moves. Beating this agent reliably as both black and white is
    the minimum requirement for solving this assignment

  - MrNovice: A minimax agent with a simple cutoff heuristic. After reaching a
    given depth in the gametree (or finding a leaf node) the current position
    will be evaluated according to a table of points for each piece left on the
    board. For a depth larger than 4, this agent is likely to run out of time
    (depending on your processor, it may manage depth 5). If you don't have
    much experience playing chess, a depth 4 MrNovice is not an easy opponent,
    but a very good agent should be able to beat it reliably as both black and
    white.

o If you find any bugs in the code, please report them to one of the TAs

--------------------------------------------------------------------------------

Author:
Hauke Neitzel
Original Authors:
Sebastian Otte and Alexander Doerr
