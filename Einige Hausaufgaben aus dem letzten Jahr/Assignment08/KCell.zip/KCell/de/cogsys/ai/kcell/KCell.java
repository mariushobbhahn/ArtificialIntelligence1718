package de.cogsys.ai.kcell;

import java.util.List;

import de.cogsys.ai.game.Agent;
import de.cogsys.ai.game.Game;
import de.cogsys.ai.game.MiniMaxAgent;

public class KCell extends Game<Integer> {
	
	public static final int EMPTY = -1; 

	public static void main(final String[] args) {
		//
		// TODO: (a) Run the game with 2 human players and 7 cells with 2 Stones 		
		//
		final Agent<Integer> player1 = new KCellHumanPlayer();
		//final Agent<Integer> player1 = new MiniMaxAgent<Integer>();
		final Agent<Integer> player2 = new MiniMaxAgent<Integer>();
		//
		// TODO: (b) Run the game without heuristic and 7 cells with 2 Stones
		//
		//AlphaBetaAgent<Integer> player1 = new AlphaBetaAgent<Integer>();
		//AlphaBetaAgent<Integer> player2 = new AlphaBetaAgent<Integer>();
		//
		// TODO: (c) Run the game with heuristics and 15 cells with 3 Stones	
		//
		// AlphaBetaAgent<Integer> player1 = new AlphaBetaAgent<Integer>([Your heuristic]);
		// AlphaBetaAgent<Integer> player2 = new AlphaBetaAgent<Integer>(new RandomKCellHeuristic());
		//
		Game.play(
			new KCell(7, 2),
			player1,
            player2,
            EMPTY
		);
	}
	
	/**
	 * Constructor
	 */
	public KCell(final int size, final int stones) {
		//
		// implement me
		//
	}

	@Override
	public double evaluate() {
		//
		// implement me
		//
		return 0;
	}

	@Override
	public int getCurrentPlayer() {
		//
		// implement me
		//
		return -1;
	}

	@Override
	public int getOtherPlayer() {
		//
		// implement me
		//
		return -1;
	}

	@Override
	public boolean wins(final int player) {
		//
		// implement me
		//
		return false;
	}

	@Override
	public boolean ends() {
		//
		// implement me
		//
		return false;
	}

	@Override
	public boolean isValidMove(final Integer move) {
		//
		// implement me
		//
		return false;
	}
	
	@Override
	public List<Integer> generateValidMoves() {
		//
		// implement me
		//
		return null;
	}

	
	@Override
	public Game<Integer> performMove(final Integer move) {
		//
		// implement me
		//
		return null;
	}

	@Override
	public String computeStringRepresentation() {
		//
		// implement me
		//
		return "";
	}

}